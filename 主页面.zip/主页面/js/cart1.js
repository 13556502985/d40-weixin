
// 更新总数和总价格，已选浮层
function getTotal() {
	var tr = $(".tr"); //行
	var foot = $('#foot');
    var seleted = 0;
    var price = 0;
    var HTMLstr = '';
    for (var i = 0, len = tr.length; i < len; i++) {
        // console.info(tr[i].getElementsByTagName('input')[0].checked+"  "+i);
        if (tr[i].getElementsByTagName('input')[0].checked) {
            tr[i].className = 'tr on';
            seleted += parseInt(tr[i].getElementsByTagName('input')[1].value);
            price += parseFloat(tr[i].cells[4].innerHTML);
            HTMLstr += '<div><img src="' + tr[i].getElementsByTagName('img')[0].src + '"><span class="del" index="' + i + '">取消选择</span></div>'
        }
        else {
            tr[i].className = ' tr';
        }
    }
    selectedTotal.innerHTML = seleted;
    priceTotal.innerHTML = price.toFixed(2);
    selectedViewList.innerHTML = HTMLstr;

    if (seleted == 0) {
        foot.className = 'foot';
    }
}
// 计算单行价格
function getSubtotal(tr) {
    var cells = tr.cells;
    var price = cells[2]; //单价
    var subtotal = cells[4]; //小计td
    var countInput = tr.getElementsByTagName('input')[1]; //数目input
    var span = tr.getElementsByTagName('span')[1]; //-号
    var span2 = tr.getElementsByTagName('span')[2] //+号;
    //写入HTML
    subtotal.innerHTML = (parseInt(countInput.value) * parseFloat(price.innerHTML)).toFixed(2);
    //如果数目只有一个，把-号去掉
    if (countInput.value == 1) {
        span.innerHTML = '';
    }else{
        span.innerHTML = '-';
    }
    if(countInput.value == 100){
        span2.innerHTML ='';
    }else{
        span2.innerHTML = '+';
    }
}

        
        // 显示已选商品弹层
        selected.onclick = function () {
            if (selectedTotal.innerHTML != 0) {
                foot.className = (foot.className == 'foot' ? 'foot show' : 'foot');
            }
        }

        //已选商品弹层中的取消选择按钮
        selectedViewList.onclick = function (e) {
            var e = e || window.event;
            var el = e.srcElement;
            if (el.className=='del') {
                var input =  tr[el.getAttribute('index')].getElementsByTagName('input')[0]
                input.checked = false;
                input.onclick();
            }
        }